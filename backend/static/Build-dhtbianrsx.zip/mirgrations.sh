python3 manage.py makemigrations users
python3 manage.py makemigrations polls
python3 manage.py migrate