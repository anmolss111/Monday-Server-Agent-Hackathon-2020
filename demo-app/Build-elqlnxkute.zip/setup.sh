apt install python3
apt install python3-pip
pip3 install django
pip3 install django_extensions
pip3 install django_rest_framework
pip3 install django-cors-headers
pip3 install django_archive
