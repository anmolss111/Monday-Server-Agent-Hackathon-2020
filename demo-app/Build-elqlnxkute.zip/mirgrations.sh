python3 manage.py makemigrations products
python3 manage.py makemigrations order
python3 manage.py migrate